<?php
/* Ispisati sve klijente (ime i prezime) sa pripadaju�im ID-ovima. */
$host="localhost";
$user="root";
$pass="root";

$link = mysql_connect ($host, $user, $pass) 
	or die ("Neuspjesno spajanje na server");
	
$link2=mysql_select_db ("autoradionica",$link);	

mysql_query("SET CHARACTER SET utf8", $link);


$upit=mysql_query("SELECT * FROM klijent ORDER BY prezimeKlijent", $link);

$a=mysql_num_rows($upit);

echo("<table border=\"1\" style=\"border-collapse:collapse;\">");
for($i=0;$i<$a;$i++)
{
	echo ("<tr> <td>");
	$b=mysql_result($upit,$i,"sifKlijent");
	echo ($b."</td> <td>");
	$b=mysql_result($upit,$i,"imeKlijent");
	echo ($b."</td> <td>");
	$b=mysql_result($upit,$i,"prezimeKlijent");

	echo($b."</td><tr/>");
}
echo ("</table>");
?>
