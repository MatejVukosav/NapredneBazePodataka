<?php

echo <<< OZNAKA
<table border="1" style="width:500px; height:500px; border-collapse:collapse; ">
OZNAKA;

for ($i=1; $i<=5; $i++)
{
	echo ("<tr>");
	for ($j=1; $j<=5; $j++)
	{
		echo ("<td>".$i."-".$j."</td>");
	}
	echo ("</tr>");
}

echo ("</table>");

?>
