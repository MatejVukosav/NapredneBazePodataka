<?php

// drugi nacin je konkateniranje svega što želimo poslati na ispis u jednu varijablu

$ispis="<html>";
$ispis.="<head>";
$ispis.="<title> Ovo je 5. labos iz naprednih baza podataka </title>";
$ispis.="</head>";
$ispis.="<body>";
$ispis.="<h1> ovo je 5. laboratorijska vježba iz Naprednih baza podataka </h1>";
$ispis.="</body>";
$ispis.="</html>";

echo ($ispis);
?>
