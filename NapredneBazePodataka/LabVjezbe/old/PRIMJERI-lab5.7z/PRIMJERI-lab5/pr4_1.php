<?php

//<tr> ozna�ava redak
//<td> ozna�ava �eliju

echo <<< EOT

<table border="1" style="width:500px; height:500px; border-collapse:collapse; ">
 <tr>
	<td> 1-1 </td>
	<td> 1-2 </td>
	<td> 1-3 </td>
	<td> 1-4 </td>
	<td> 1-5 </td>
 </tr>
 
 <tr>
	<td> 2-1 </td>
	<td> 2-2 </td>
	<td> 2-3 </td>
	<td> 2-4 </td>
	<td> 2-5 </td>
 </tr>
 
 <tr>
	<td> 3-1 </td>
	<td> 3-2 </td>
	<td> 3-3 </td>
	<td> 3-4 </td>
	<td> 3-5 </td>
 </tr>
 
 <tr>
	<td> 4-1 </td>
	<td> 4-2 </td>
	<td> 4-3 </td>
	<td> 4-4 </td>
	<td> 4-5 </td>
 </tr>
 
 <tr>
	<td> 5-1 </td>
	<td> 5-2 </td>
	<td> 5-3 </td>
	<td> 5-4 </td>
	<td> 5-5 </td>
 </tr>

</table>

EOT;

?>

