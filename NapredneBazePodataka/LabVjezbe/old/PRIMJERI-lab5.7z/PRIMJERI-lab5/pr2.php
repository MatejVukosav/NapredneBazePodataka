<?php

// U prvom ispisu pokazan je primjer ispisa tri stringa konkatenirana operatorom konkatenacije (koji je u php-u to�ka).

echo ("<h1>"."Hello World"."</h1>");

// U drugom primjeru ispisujemo jedan string u kojem su i tagovi i sadr�aj.

echo ("<h1> Hello World </h1>");

// Tre�i primjer je konkatenacija tri stringa u varijablu $ispis, koja se nakon toga ispisuje. (Podsjetimo se da u PHP-u svi nazivi varijabla po�inju oznakom $. Varijable nije potrebno deklarirati ve� ih mo�emo samo po�eti koristiti.)

$ispis="<h1>"."Hello World"."</h1>";
echo($ispis);

?>
