<?php

// preglednik �e primiti i poku�ati obraditi string, a kako nema nikakvih tagova i oznaka, samo �e ga ispisati na ekran

echo ("Hello World");

?>
