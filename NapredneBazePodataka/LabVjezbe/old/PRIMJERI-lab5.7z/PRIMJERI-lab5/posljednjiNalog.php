<!-- Napisati skriptu koja �e se spojiti na bazu podataka autoradionica na lokalnom poslu�itelju sa sljede�im podacima:
�	korisni�ko ime: admin
�	lozinka: jura

Nakon toga skripta mora za zadani po�tanski broj mjesta ispisati ime i prezime klijenta za kojeg je 
posljednje zaprimljen nalog (nalog.datPrimitkaNalog) a �ivi u tom mjestu. 

U ispisu se trebaju vidjeti samo gore navedene kolone.

Ako je potrebno izdajte si (minimalne) potrebne dozvole za rad nad bazom podataka. 
-->
<!--SQL: 
GRANT SELECT ON autoradionica.klijent TO 'admin'@'localhost' IDENTIFIED BY 'jura';
GRANT SELECT ON autoradionica.nalog TO 'admin'@'localhost' IDENTIFIED BY 'jura';
-->
<!--script-->
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=cp1250">
</head>
<body>

<?php
if (isset($_POST['naziv']))
{

$host="localhost";
$user="admin";
$pass="jura";
$link = mysql_connect ($host, $user, $pass)
or die ("Neuspjesno spajanje na server");
$link2=mysql_select_db ("autoradionica",$link);
mysql_query("SET CHARACTER SET cp1250", $link);

$upit=mysql_query("SELECT * FROM klijent JOIN nalog on klijent.sifKlijent=nalog.sifKlijent 
WHERE pbrKlijent='$_POST[naziv]' order by nalog.datPrimitkaNalog desc", $link);

echo "Mjesto: ".$_POST['naziv']."</br>";
echo <<< EOT
<table border="1" style="border-collapse:collapse;">
<tr>
<th> Ime klijenta </th>
<th> Prezime klijenta </th>
</tr>
EOT;
$row=mysql_fetch_array($upit);

echo <<< EOT
<tr>
<td> {$row['imeKlijent']} </td>
<td> {$row['prezimeKlijent']} </td>

</tr>
EOT;

echo "</table>";

}
else
{
echo '<form action="#" method="post">
Unesite po�tanski broj:
</br>
<input type="text" name="naziv"/>
<input type="submit" value="Dohvati"/>
</form>
';
}
?>

</body>
</html> 