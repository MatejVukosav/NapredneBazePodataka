<?php

//primjer slanja svakog stringa zasebno
echo ("<html>");
echo ("<head>");
echo ("<title> Ovo je 5. labos iz Naprednih baza podatka </title>");
echo ("</head>");
echo ("<body>");
echo ("<h1> Ovo je 5. labos </h1>");
echo ("</body>");
echo ("</html>");
?>
