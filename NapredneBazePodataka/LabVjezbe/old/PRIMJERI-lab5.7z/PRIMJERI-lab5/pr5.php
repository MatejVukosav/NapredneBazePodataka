﻿<?php

$host="localhost";
$user="root";
$pass="root";

$link = mysql_connect ($host, $user, $pass) 
	or die ("Neuspjesno spajanje na server");
	
echo "Uspješno spajanje na poslužitelj!";

?>
