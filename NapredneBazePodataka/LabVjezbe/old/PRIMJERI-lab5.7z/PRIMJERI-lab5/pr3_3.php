﻿<?php

//treći način je višeredni ispis u kojem ispisujemo sve između oznaka 'echo <<< EOT' i 'EOT' (
//umjesto oznake EOT (End Of Text) možemo koristiti bilo koji drugi niz grafema, 
//primjerice 'echo <<< OZNAKA' i 'OZNAKA'
//oprez: ključna riječ EOT mora se pisati od početka retka (bez razmaka)

echo <<< EOT

<html>

<head>
<title> Ovo je 5. vježba iz Naprednih Baza podataka </title>
</head>

<body>
<h1> ovo je 5. laboratorijska vježba iz Naprednih baza podataka </h1>
</body>
</html>

EOT;


// varijable
$a=5;
$b=10;

$c=$a+$b;

echo ($c);

?>
