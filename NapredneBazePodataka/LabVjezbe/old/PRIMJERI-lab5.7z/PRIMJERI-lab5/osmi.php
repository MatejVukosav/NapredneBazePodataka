<?php

$host="localhost";
$user="root";
$pass="root";

$link = mysql_connect ($host, $user, $pass) 
	or die ("Neuspjesno spajanje na server");
	
$link2=mysql_select_db ("autoradionica",$link);	

$upit=mysql_query("SELECT MAX(sifklijent) AS maks FROM klijent;", $link);	
$max=mysql_result($upit,0,"maks");

$ime=$_POST['ime'];
$prezime=$_POST['prezime'];
$id_novog_klijenta=$max+1;

$unos="INSERT INTO klijent (sifKlijent,imeKlijent,prezimeKlijent) VALUES ($id_novog_klijenta,'$ime','$prezime')";

$upit2=mysql_query($unos,$link)
	or die ("Nisam uspio upisati u bazu");

//header('Location: osmi.html');
header('Location: pr7.php');
?>

